package fr.isen.ticketapp.interfaces.models.enums;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0268e850-fe23-4071-a7dd-b96e6801d0fd")
public enum ROLE {
    Utilisateur,
    Intervenant;
}
