package fr.isen.ticketapp.interfaces.models;

import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.ticketapp.interfaces.models.enums.ROLE;

@objid ("88b638a5-cfbd-43cf-bbd9-236308ab2889")
public class Utilisateurs {
    @mdl.prop
    @objid ("f67729e4-3442-4178-a031-6dbfe0263d60")
    private int id;

    @mdl.prop
    @objid ("55ff5fa3-90cb-4550-9cc5-87132a80b2a1")
    private String nom;

    @mdl.prop
    @objid ("32e5c7fd-8c6f-44e4-9014-1f9e66163ee9")
    private String email;

    @mdl.prop
    @objid ("a896590c-2109-46e7-b006-d70c482bd4cc")
    private String motDePasse;

    @mdl.prop
    @objid ("ae405735-867b-4528-9924-32dd1d13b0a4")
    private String dateDerniereConnexion;

    @mdl.prop
    @objid ("bc745505-00f7-4fc9-ab1d-406ea997f442")
    private boolean statut;

    @mdl.prop
    @objid ("4a9b33b6-420d-4437-8704-9ee14a47f508")
    private ROLE role;

}
