package fr.isen.ticketapp.interfaces.models.enums;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("98fb96f9-b703-4ace-8d08-7c1cb1b98366")
public enum IMPACT {
    Bloquant,
    Mineur,
    Majeur;
}
