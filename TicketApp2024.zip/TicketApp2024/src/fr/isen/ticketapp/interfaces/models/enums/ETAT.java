package fr.isen.ticketapp.interfaces.models.enums;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("c48ebd84-79b2-4cac-9fca-9730ce7e44e4")
public enum ETAT {
    Ouvert,
    EnCours,
    Résolu,
    Fermé,
    Annulé;
}
