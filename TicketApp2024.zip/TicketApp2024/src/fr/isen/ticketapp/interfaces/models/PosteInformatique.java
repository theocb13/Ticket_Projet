package fr.isen.ticketapp.interfaces.models;

import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.ticketapp.interfaces.models.enums.ETATPOSTE;

@objid ("4bcf29ae-aa84-4f3f-9935-f3e14ab83b46")
public class PosteInformatique {
    @mdl.prop
    @objid ("910d865d-1925-4734-a741-b76ce64f3629")
    private int id;

    @mdl.prop
    @objid ("3eec67b2-7c9b-42f3-8477-4519bfed65b7")
    private Utilisateurs utilisateurAffecte;

    @mdl.prop
    @objid ("7e721303-a41f-4846-a62c-fc5beccbc782")
    private ETATPOSTE etat;

    @mdl.prop
    @objid ("6db2f34a-fdf9-4a59-a8ae-5109e4af20c5")
    private String configuration;

}
