package fr.isen.ticketapp.interfaces.models;

import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.ticketapp.interfaces.models.enums.ETAT;
import fr.isen.ticketapp.interfaces.models.enums.IMPACT;

@objid ("f6dcaab9-2bed-416e-aca1-3b2822e7947b")
public class TicketModel {
    @mdl.prop
    @objid ("28d31d5d-3033-429a-894b-6d1826b0dba0")
    private int id;

    @mdl.prop
    @objid ("f391515a-3658-4738-9838-2e6d684eb2d3")
    private IMPACT impact;

    @mdl.prop
    @objid ("84bd3b55-4451-4279-9d4e-0c779d70e551")
    private String Titre;

    @mdl.prop
    @objid ("64dbe3bc-b97f-4e12-956f-2b51594d490d")
    private String email;

    @mdl.prop
    @objid ("4adfeaec-3b4a-4234-b3ee-551974083708")
    private String description;

    @mdl.prop
    @objid ("73d3b4fc-0958-4730-951d-5a5937a49c35")
    private Date dateCreation;

    @mdl.prop
    @objid ("e787f732-17fb-425a-91a0-6d6dcf46f212")
    private Date dateMiseAJour;

    @mdl.prop
    @objid ("3175d926-2643-4df5-ba5c-4bfed8168e2a")
    private ETAT Etat;

    @mdl.prop
    @objid ("f60f1760-1318-456f-8f94-99a6a0e86fb7")
    private Utilisateurs createur;

    @mdl.prop
    @objid ("75264fc9-8aa8-4b1f-81a2-ae849b53ee14")
    private PosteInformatique posteInformatique;

    @mdl.prop
    @objid ("784388f5-0707-432d-b576-2678d46b9038")
    private String typeDemande;

}
