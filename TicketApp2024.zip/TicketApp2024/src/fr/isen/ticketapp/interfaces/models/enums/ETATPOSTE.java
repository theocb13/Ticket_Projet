package fr.isen.ticketapp.interfaces.models.enums;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6327291c-e7fb-406f-a02e-00efa7ffba70")
public enum ETATPOSTE {
    EnFonction,
    EnMaintenance,
    EnCommande;
}
