package fr.isen.ticketapp.interfaces.services;

import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.ticketapp.interfaces.models.Utilisateurs;

@objid ("f9b022fd-8782-4f7e-8061-6f2baa5fea6e")
public interface UsersServices {
    @objid ("96ac77f3-aba5-413a-aa17-5a83e8a3bd55")
    List<Utilisateurs> getAllUsers();

    @objid ("ebeb7bb8-17e2-4d9c-a79d-6bb74b4ab3fd")
    Utilisateurs getUserById(final int id);

    @objid ("4639871b-e2cc-4ff4-bf69-19f9f43748f2")
    Utilisateurs addUser(final Utilisateurs user);

    @objid ("8cbbfaf1-8bb3-443a-bb45-d0bb7d393bfa")
    boolean removeUser(final int UserId);

    @objid ("64e73b4d-6208-44a9-91ee-cadfd5fd5fdf")
    Utilisateurs updateUser(final Utilisateurs newUser);

}
