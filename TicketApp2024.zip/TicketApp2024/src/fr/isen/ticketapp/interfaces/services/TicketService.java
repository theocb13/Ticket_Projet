package fr.isen.ticketapp.interfaces.services;

import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.ticketapp.interfaces.models.TicketModel;

@objid ("d2a90d01-0d38-4d0e-8112-d47b1e823a91")
public interface TicketService {
    @objid ("73ef0185-c4cc-43e7-ae92-3080dead18fc")
    List<TicketModel> getAllTicket();

    @objid ("223c14ac-f3ed-461d-a287-af0c0d8ff95e")
    TicketModel getTicketById(final int id);

    @objid ("045f1a9e-6456-4661-a046-f921f6ec414d")
    TicketModel addTicket(final TicketModel user);

    @objid ("13ecdf80-e0b0-400d-ac27-066482a4ea89")
    boolean removeTicket(final int ticketId);

    @objid ("e3b0cf8f-4be3-4cd6-936d-caec830a152a")
    TicketModel updateTicket(final TicketModel newTicket);

}
