package fr.isen.ticketapp.interfaces.services;

import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.ticketapp.interfaces.models.PosteInformatique;

@objid ("2199d445-075e-4e6c-ae1e-f34787497742")
public interface DeviceServices {
    @objid ("85e67e26-8561-4cac-92d7-aa36f4c160a9")
    List<PosteInformatique> getAllDevice();

    @objid ("a0a6ffed-d966-49b2-82fb-7e588fffe342")
    PosteInformatique getDeviceById(final int id);

    @objid ("7cc66c54-191d-4797-919a-bf4986f2c432")
    PosteInformatique addDevice(final PosteInformatique device);

    @objid ("6d38097f-fec5-4040-9283-5270ff76848f")
    boolean removeDevice(final int deviceId);

    @objid ("09abdce0-5337-4bb9-aa00-fd85d6f7317d")
    PosteInformatique updateDevice(final PosteInformatique newDevice);

}
